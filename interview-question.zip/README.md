# JSON API

### For running the application using the following commands in terminal

```sh
$ npm i
$ npm run start
```